# UPSTREAM 取り込み方針（Katamari）
- Upstream: Chainlit/chainlit（Apache-2.0）
- 追従ポリシー: 最新安定タグを週次でチェックし取り込み
- 直近開始日時: 2025-10-19 JST
- 差分は `core_ext/` に隔離、`app.py` は薄い配線のみ。
