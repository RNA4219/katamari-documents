
# Release Checklist
- [ ] Bump version & tag
- [ ] Update docs/UPSTREAM.md
- [ ] Run tests & lint
- [ ] Build Docker image
- [ ] Verify SSE streaming & OAuth (if enabled)
