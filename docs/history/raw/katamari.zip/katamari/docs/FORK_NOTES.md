# FORK_NOTES（Katamari）
- 追加点：persona_compiler / context_trimmer / prethought / multistep / evolve
- Provider抽象（OpenAI/Gemini）・/metrics・/healthz・/api/models
- ライセンス: Apache-2.0相当（LICENSE/NOTICE同梱前提）
