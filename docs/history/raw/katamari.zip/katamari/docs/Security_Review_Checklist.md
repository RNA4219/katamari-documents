
# Security Review Checklist
- [ ] Secrets in ENV only (no logs)
- [ ] CORS limited
- [ ] Rate limit enabled
- [ ] OAuth redirect validated
- [ ] Dependencies scanned
