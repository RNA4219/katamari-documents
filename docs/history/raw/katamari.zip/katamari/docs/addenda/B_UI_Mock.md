# 付録B: UIモック（ASCII）
**Status: 2025-10-19 JST**

```
┌ Katamari (Chainlit Fork) ───────────────────────────────────────────────┐
│ [Settings]  Model: gpt-5-main  Chain: reflect  Trim: 4096  Debug: off  │
├────────────────────────────────────────────────────────────────────────┤
│  user > これ要件まとめて                                              │
│  sys  # Step 1: draft                                                 │
│  asst streaming... こんにちは、要件の骨子は…                           │
│                                                                        │
│  sys  # Step 2: critique                                              │
│  asst streaming... 懸念点は…                                          │
│                                                                        │
│  sys  # Step 3: final                                                 │
│  asst streaming... 最終案です。                                        │
│                                                                        │
│  [trim] tokens: 1900/7200 (ratio 0.26)                                 │
├────────────────────────────────────────────────────────────────────────┤
│ > メッセージ入力… [Enter=送信 / Shift+Enter=改行]  [Stop]              │
└────────────────────────────────────────────────────────────────────────┘
```
