# 付録M: バージョニング & リリース
**Status: 2025-10-19 JST**

- バージョン: `MAJOR.MINOR.PATCH`（例: 0.3.1）
- タグ: `vX.Y.Z-katamari`
- リリースノート: 変更点・既知の問題・Upstream取り込みタグ
- CI（M3）: lint → unit → build → package(zip/docker) → release
