# 付録L: 設定リファレンス
**Status: 2025-10-19 JST**

- `OPENAI_API_KEY`, `GEMINI_API_KEY`, `DEFAULT_PROVIDER`
- `CHAINLIT_AUTH_SECRET`
- `PORT`, `LOG_LEVEL`
- `model_registry.json`：`id/provider/family/type/reasoning/(parallel)/maxTokens/price*`
