# Katamari Theme Catalog (16 presets)

- katamari-classic
- katamari-minty
- katamari-mocha
- katamari-highcontrast
- katamari-sakura
- katamari-yuzu
- katamari-matcha
- katamari-sky
- katamari-ocean
- katamari-lavender
- katamari-twilight
- katamari-sunset
- katamari-midnight
- katamari-graphite
- katamari-solarized-light
- katamari-solarized-dark
