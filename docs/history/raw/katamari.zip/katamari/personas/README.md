# Katamari Persona Catalog (Samples)
**Updated**: 2025-10-19 JST

## List
- `01_concise_engineer.yaml` — 01 concise engineer
- `02_friendly_mentor.yaml` — 02 friendly mentor
- `03_prompt_optimizer.yaml` — 03 prompt optimizer
- `04_debug_partner.yaml` — 04 debug partner
- `05_product_manager_spec.yaml` — 05 product manager spec
- `06_academic_researcher.yaml` — 06 academic researcher
- `07_translator_ja_en.yaml` — 07 translator ja en
- `08_storyteller_concise.yaml` — 08 storyteller concise
- `09_field_ops_helper.yaml` — 09 field ops helper
- `10_spec_to_tasklist.yaml` — 10 spec to tasklist
- `11_evaluator_bertscore.yaml` — 11 evaluator bertscore
- `12_minimal_assistant.yaml` — 12 minimal assistant
